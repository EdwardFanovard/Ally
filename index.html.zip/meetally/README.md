# Ally — deploy guide (GitHub + Netlify + Gemini)

This folder is a complete, working site: a static front end (`index.html`)
plus a small serverless function (`netlify/functions/chat.js`) that calls
Google's Gemini API on your behalf, so the AI chat works on your own
domain, with your key kept secret on the server.

## 1. Get a Gemini API key

1. Go to https://aistudio.google.com/apikey and sign in with a Google account.
2. Click **Create API key**. Copy it somewhere safe — you won't be shown
   it again in full.
3. Gemini has a free tier with generous limits for light traffic; check
   current quotas and pricing at https://ai.google.dev/pricing before
   relying on it for real, sustained usage.

## 2. Put this project on GitHub

If you don't already have Git installed, get it from https://git-scm.com.
Then, from inside this `meetally` folder:

```
git init
git add .
git commit -m "Ally: free AI helper, Gemini backend"
```

Create a new empty repository on https://github.com/new (name it
`meetally`, don't add a README there), then:

```
git remote add origin https://github.com/YOUR-USERNAME/meetally.git
git branch -M main
git push -u origin main
```

## 3. Connect the repo to Netlify

1. Go to https://app.netlify.com and sign in (free tier is fine).
2. Click **Add new site > Import an existing project**.
3. Choose **GitHub**, authorize Netlify, and pick the `meetally` repo.
4. Build settings: leave the build command empty and publish directory
   as `.` — this repo has no build step, `netlify.toml` already tells
   Netlify where the function lives.
5. Before the first deploy finishes, add your key: **Site settings >
   Environment variables > Add a variable** — name it `GEMINI_API_KEY`,
   paste your key as the value.
6. Click **Deploy**. Netlify gives you a live URL immediately, e.g.
   `https://random-name-123.netlify.app`.

From now on, every `git push` to `main` redeploys the site automatically
— no manual steps.

## 4. Claim the "meetally" name

In Netlify: **Site settings > Change site name**, type `meetally`. If
it's taken, try `meetallyapp` or `himeetally`.

## 5. Test it

Open your live URL, send a message, and confirm you get a real reply
back from Gemini. Try "Remember me," reload the page, and confirm the
memory banner appears (this part still uses the browser's local storage
— nothing to configure).

## Costs and limits to expect

- Netlify's free tier: no cost for a site like this at low traffic.
- Gemini API: free tier covers light use; heavier traffic moves into
  paid, pay-as-you-go pricing. Check usage at
  https://aistudio.google.com and set a budget alert if you can find
  one under your Google Cloud billing (Gemini API billing is tied to a
  Google Cloud project once you're past the free tier).
- Consider a simple per-visitor rate limit in `chat.js` (e.g. "20
  messages a day") before sharing the link widely — ask me for that
  code whenever you're ready to add it.
