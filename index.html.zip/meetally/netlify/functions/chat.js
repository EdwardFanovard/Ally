// netlify/functions/chat.js
//
// This runs on Netlify's server, never in the visitor's browser, so the
// API key stays secret. The front end (index.html) calls this at
// /.netlify/functions/chat. It talks to Google's Gemini API.

const GEMINI_MODEL = 'gemini-2.5-flash'; // stable as of writing — check
// https://ai.google.dev/gemini-api/docs/models for the current
// recommended model string if this ever stops working; Google retires
// model versions on a schedule.

exports.handler = async function (event) {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: JSON.stringify({ error: 'Method not allowed' }) };
  }

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: 'Server is missing GEMINI_API_KEY. Set it in Site settings > Environment variables.' })
    };
  }

  let payload;
  try {
    payload = JSON.parse(event.body || '{}');
  } catch (e) {
    return { statusCode: 400, body: JSON.stringify({ error: 'Malformed request body.' }) };
  }

  const { prompt, memory, raw } = payload;
  if (!prompt || typeof prompt !== 'string') {
    return { statusCode: 400, body: JSON.stringify({ error: 'Missing "prompt" in request.' }) };
  }

  // "raw" is used for the internal memory-summary call, which needs no
  // Ally persona wrapper. Everything else gets the Ally system framing.
  const content = raw
    ? prompt
    : 'You are Ally, a free, friendly AI helper on a website used by all kinds of people — students, kids, ' +
      'working parents, people at their jobs, families at home. Answer clearly and simply, avoid jargon, keep a ' +
      'warm and encouraging tone, and keep the answer reasonably short unless the question truly needs more detail. ' +
      'If the question involves numbers or steps, lay them out plainly.' +
      (memory ? '\n\nWhat you remember about this person from before: ' + memory : '') +
      '\n\nTheir question: "' + prompt + '"';

  try {
    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-goog-api-key': apiKey
        },
        body: JSON.stringify({
          contents: [{ role: 'user', parts: [{ text: content }] }],
          generationConfig: { maxOutputTokens: 500 }
        })
      }
    );

    const data = await response.json();

    if (!response.ok) {
      return {
        statusCode: response.status,
        body: JSON.stringify({ error: (data && data.error && data.error.message) || 'Gemini API error.' })
      };
    }

    const candidate = data.candidates && data.candidates[0];
    const text = candidate && candidate.content && candidate.content.parts
      ? candidate.content.parts.map((p) => p.text || '').join('\n')
      : '';

    if (!text) {
      // Gemini can return an empty result if it blocked the response for
      // safety reasons — surface something sensible instead of silence.
      const reason = candidate && candidate.finishReason;
      return {
        statusCode: 200,
        body: JSON.stringify({ text: "I can't help with that one — try asking it a different way." , blocked: reason || null })
      };
    }

    return { statusCode: 200, body: JSON.stringify({ text }) };
  } catch (err) {
    return { statusCode: 500, body: JSON.stringify({ error: 'Could not reach the AI service. Try again shortly.' }) };
  }
};
